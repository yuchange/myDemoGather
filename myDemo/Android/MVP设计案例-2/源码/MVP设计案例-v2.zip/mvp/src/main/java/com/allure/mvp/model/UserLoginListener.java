package com.allure.mvp.model;

/**
 * 作者：luomin
 * 邮箱：asddavid@163.com
 */
public interface UserLoginListener {
    void loginSuccess();
    void loginFailed();
}
