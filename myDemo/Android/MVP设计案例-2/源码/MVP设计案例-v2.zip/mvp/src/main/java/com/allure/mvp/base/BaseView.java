package com.allure.mvp.base;

/**
 * 作者：luomin
 * 邮箱：asddavid@163.com
 */

public interface BaseView {
    void showLoading();
    void hideLoading();
}
