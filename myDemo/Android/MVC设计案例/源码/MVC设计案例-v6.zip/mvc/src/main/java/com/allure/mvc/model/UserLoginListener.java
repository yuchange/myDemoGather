package com.allure.mvc.model;

/**
 * 作者：luomin on 16/12/27 08:05
 * 邮箱：asddavid@163.com
 */
public interface UserLoginListener {
    void loginSuccess();

    void loginFailed();
}
